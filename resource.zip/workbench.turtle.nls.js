define("vs/workbench/workbench.turtle.nls",{
	tableBar:['Debug Console','Output','Problem','Integrated Terminal']
});
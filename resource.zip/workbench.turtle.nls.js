define("vs/workbench/workbench.turtle.nls",{
	tableBar:['Debug Console','Output','Problem','Integrated Terminal','Extensions','Git','Search','Explorer','Deubug']
});
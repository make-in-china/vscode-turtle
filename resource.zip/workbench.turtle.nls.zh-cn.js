define("vs/workbench/workbench.turtle.nls.zh-cn",{
	tableBar:['调试','输出','问题','终端','插件','Git','搜索','文件','调试']
});
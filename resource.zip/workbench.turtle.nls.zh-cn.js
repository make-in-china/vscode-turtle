define("vs/workbench/workbench.turtle.nls.zh-cn",{
	tableBar:['调试','输出','问题','终端']
});